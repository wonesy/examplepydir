from fruit.banana import Banana


class Apple:
    def __init__(self) -> None:
        self.name = "Apple boy"
        self.banana = Banana("yellow")
