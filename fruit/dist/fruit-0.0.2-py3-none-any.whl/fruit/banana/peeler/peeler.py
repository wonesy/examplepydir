class Peeler:
    def __init__(self) -> None:
        self.name = "Peely boy"
